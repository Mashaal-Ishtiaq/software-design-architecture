import javax.swing.*;

public class StudentView {
    public String[] setStudentDetails()
    {
        String []Data = new String[2];
        Data[0] = JOptionPane.showInputDialog("Student's Name: ");
        Data[1] = JOptionPane.showInputDialog("Student's Roll No: ");
        return Data;
    }
    public void printStudentDetails(String studentName, String studentRollNo){
        System.out.println("Student: ");
        System.out.println("Name: " + studentName);
        System.out.println("Roll No: " + studentRollNo);
    }
}