public class StudentController {
    private Student model;
    private StudentView view;
    public StudentController(Student model, StudentView view){
        this.model = model;
        this.view = view;
    }
    public void setStudent(){
        String []data = view.setStudentDetails();
        model.setName(data[0]);
        model.setRollNo(data[1]);
    }
    public String getStudentName(){
        return model.getName();
    }

    public String getStudentRollNo(){
        return model.getRollNo();
    }
    public void updateView(){
        view.printStudentDetails(model.getName(), model.getRollNo());
    }
}