// CalculatorController.java
public class CalculatorController {
    private CalculatorModel model;
    private CalculatorView view;

    public CalculatorController(CalculatorModel model, CalculatorView view) {
        this.model = model;
        this.view = view;
    }

    public void start() {
        try {
            int num1 = view.getNumber("Enter first number: ");
            int num2 = view.getNumber("Enter second number: ");
            String operation = view.getOperation();

            switch (operation) {
                case "+":
                    model.add(num1, num2);
                    view.displayResult(model.getValue());
                    break;
                case "-":
                    model.subtract(num1, num2);
                    view.displayResult(model.getValue());
                    break;
                default:
                    view.displayErrorMessage("Invalid operation.");
            }
        } catch (Exception e) {
            view.displayErrorMessage("Please enter valid integers.");
        }
    }
}

