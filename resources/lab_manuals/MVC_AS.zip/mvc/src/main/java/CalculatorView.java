// CalculatorView.java
import java.util.Scanner;

public class CalculatorView {
    private Scanner scanner = new Scanner(System.in);

    public int getNumber(String prompt) {
        System.out.print(prompt);
        return scanner.nextInt();
    }

    public void displayResult(int result) {
        System.out.println("Result: " + result);
    }

    public void displayErrorMessage(String errorMessage) {
        System.out.println(errorMessage);
    }

    public String getOperation() {
        System.out.print("Enter operation (+ or -): ");
        return scanner.next();
    }
}
