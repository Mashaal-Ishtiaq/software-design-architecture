// CalculatorModel.java
public class CalculatorModel {
    private int value;

    public void add(int num1, int num2) {
        value = num1 + num2;
    }

    public void subtract(int num1, int num2) {
        value = num1 - num2;
    }

    public int getValue() {
        return value;
    }
}
