/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package practice.registration_mvc;

/**
 *
 * @author HP
 */
public class Registration_mvc {

   public static void main(String[] args){
        Registration r = new Registration();
        student s =new student("","","","","","","");
        controller c=new controller(r,s);
    }
}
