/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practice.registration_mvc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.JOptionPane;

public class controller {
    Registration view;
    student model;
    
    public controller(Registration view, student model) {
        this.view = view;
        this.model = model;

        // Add action listeners
        view.btSubmit.addActionListener(new SaveButtonListener());
        view.txtRollNo.addFocusListener(new RollNoFocusListener());

        // Add listeners for other buttons if needed
    }

    // ActionListener for Submit button
    class SaveButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Get data from the view and update the model
            model = view.collectInfo();
            displayInfo(model);
        }
    }

    // FocusListener for Roll No text field
    class RollNoFocusListener implements FocusListener {
        @Override
        public void focusGained(FocusEvent e) {
            // Not needed for this example
        }

        @Override
        public void focusLost(FocusEvent e) {
            // Generate and set email based on Roll No
            if (view.txtRollNo.getText().isEmpty()) {
                view.txtEmail.setText("");
            } else {
                String rollno = view.txtRollNo.getText();
                String[] r = rollno.toUpperCase().split("P-");
                String email = "p" + r[0] + r[1] + "@pwr.nu.edu.pk";
                view.txtEmail.setText(email);
            }
        }
    }
    public void displayInfo(student a)
    {
        
        JOptionPane.showMessageDialog(view.contentPane, "Name: "+a.getName()+"\nFather's Name: "+a.getFather()+"\nGender: "+a.getGender()+"\nContact: "+a.getContact()+"\nRoll no: "+a.getRollno()+"\nEmail: "+a.getEmail()+"\nAddress: "+a.getAddress());
        //System.out.println("Name: "+name+"\nFather's Name: "+father+"\nGender: "+gender);
    }
    
    public String getName() {
       return model.getName();
    }

    public void setName(String name) {
         model.setName(name);
    }

    public String getFather() {
        return model.getFather();
    }

    public void setFather(String father) {
        model.setFather(father);
    }

    public String getGender() {
        return model.getGender();
    }

    public void setGender(String gender) {
        model.setGender(gender);
        
    }

    public String getContact() {
        return model.getContact();
    }

    public void setContact(String contact) {
        model.setContact(contact);
    }

    public String getRollno() {
        return model.getRollno();
    }

    public void setRollno(String rollno) {
        model.setRollno(rollno);
        
    }

    public String getEmail() {
        
        return model.getEmail();
    }

    public void setEmail(String email) {
        
       model.setEmail(email);
    }

    public String getAddress() {
        return model.getAddress();
    }

    public void setAddress(String address) {
        model.setAddress(address);
    }
    
}
