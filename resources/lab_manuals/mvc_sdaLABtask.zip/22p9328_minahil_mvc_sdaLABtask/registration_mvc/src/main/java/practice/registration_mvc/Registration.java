/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practice.registration_mvc;

/**
 *
 * @author HP
 */
import javax.swing.*;
import java.awt.*;

public class Registration extends JFrame {
    final JPanel contentPane;
    private final JTextField txtName;
    private final JTextField txtFather;
    private final JComboBox<String> cbGender;
    private final JTextField txtContact;
    final JTextField txtRollNo;
    final JTextField txtEmail;
    private final JTextArea txtAddress;
    final JButton btSubmit;

    public Registration() {
        contentPane = new JPanel(new GridLayout(8, 2));
        setContentPane(contentPane);

        txtName = new JTextField(20);
        txtFather = new JTextField(20);
        cbGender = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        txtContact = new JTextField(20);
        txtRollNo = new JTextField(20);
        txtEmail = new JTextField(20);
        txtAddress = new JTextArea(5, 20);
        btSubmit = new JButton("Submit");

        contentPane.add(new JLabel("Name:"));
        contentPane.add(txtName);
        contentPane.add(new JLabel("Father's Name:"));
        contentPane.add(txtFather);
        contentPane.add(new JLabel("Gender:"));
        contentPane.add(cbGender);
        contentPane.add(new JLabel("Contact:"));
        contentPane.add(txtContact);
        contentPane.add(new JLabel("Roll No:"));
        contentPane.add(txtRollNo);
        contentPane.add(new JLabel("Email:"));
        contentPane.add(txtEmail);
        contentPane.add(new JLabel("Address:"));
        contentPane.add(txtAddress);
        contentPane.add(new JPanel()); // Empty panel for spacing
        contentPane.add(btSubmit);

        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Student's Registration");
        setLocationRelativeTo(null);
        setVisible(true);
    }

    student collectInfo()
    {
        student a;
        a = new student(txtName.getText(),txtFather.getText(),cbGender.getSelectedItem().toString(),txtContact.getText(),txtRollNo.getText(),txtEmail.getText(),txtAddress.getText());
        return a;
    }
    
    
    
}


    



