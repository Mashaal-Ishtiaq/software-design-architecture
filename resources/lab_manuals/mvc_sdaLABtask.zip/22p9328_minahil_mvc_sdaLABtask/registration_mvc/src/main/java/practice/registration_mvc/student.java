/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practice.registration_mvc;

/**
 *
 * @author HP
 */
public class student {
        String name ;
        String father  ;
        String gender ;
        String contact ;
        String rollno ;
        String email ;
        String address ;

    public student(String name, String father, String gender, String contact, String rollno, String email, String address) {
        this.name = name;
        this.father = father;
        this.gender = gender;
        this.contact = contact;
        this.rollno = rollno;
        this.email = email;
        this.address = address;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFather() {
        return father;
    }

    public void setFather(String father) {
        this.father = father;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getRollno() {
        return rollno;
    }

    public void setRollno(String rollno) {
        this.rollno = rollno;
        
    }

    public String getEmail() {
        
        return email;
    }

    public void setEmail(String email) {
        
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
        
    
}
